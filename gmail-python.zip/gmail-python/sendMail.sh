./enviaMail.sh
