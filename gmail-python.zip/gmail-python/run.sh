cd /home/ruben/Proyectos-RGA/gmail-python
rm -f datosEnviar.txt
python trataXML.py
./sendMail.sh

